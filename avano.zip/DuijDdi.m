function d = DuijDdi(Vi, Vj, Gij, Bij, deltai, deltaj)
d = -DuijDdj(Vi, Vj, Gij, Bij, deltai, deltaj);