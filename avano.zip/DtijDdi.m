function d = DtijDdi(Vi, Vj, Gij, Bij, deltai, deltaj)
d = -DtijDdj(Vi, Vj, Gij, Bij, deltai, deltaj);